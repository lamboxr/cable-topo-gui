def get_gpkg_path(gpkg_file_name):
    gpkg_path = r"./gpkg/" +gpkg_file_name
    return gpkg_path